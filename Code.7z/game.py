class Store():
    def __init__(self):
        self.ps = []
    
    def add_one_record(self,parameter,score):
        self.ps.append((parameter,score))
   
   
        

        